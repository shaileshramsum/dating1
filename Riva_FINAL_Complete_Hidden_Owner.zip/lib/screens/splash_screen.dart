
import 'package:flutter/material.dart';
import 'role_select.dart';
import 'owner/owner_login.dart';
class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}
class _SplashScreenState extends State<SplashScreen> {
  int tapCount=0; DateTime? lastTap;
  @override
  void initState() { super.initState(); Future.delayed(Duration(seconds: 2), (){ Navigator.pushReplacement(context, MaterialPageRoute(builder: (_)=> RoleSelectHidden())); }); }
  void _secretTap(){
    final now=DateTime.now();
    if(lastTap==null || now.difference(lastTap!).inSeconds>2) tapCount=1; else tapCount++;
    lastTap=now;
    if(tapCount>=5){ tapCount=0; ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Owner Mode Activated'))); Navigator.push(context, MaterialPageRoute(builder: (_)=> OwnerLoginHidden())); }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(body: Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [Color(0xFFFF4B6E), Color(0xFFFF8C42)])), child: Center(child: GestureDetector(onTap: _secretTap, child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.favorite, size: 100, color: Colors.white), Text('Riva Dil', style: TextStyle(fontSize: 48, fontWeight: FontWeight.bold, color: Colors.white)), Text('Find Your Vibe', style: TextStyle(color: Colors.white70)), SizedBox(height: 30), CircularProgressIndicator(color: Colors.white)])))));
  }
}
