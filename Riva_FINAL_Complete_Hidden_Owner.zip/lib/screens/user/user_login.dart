
import 'package:flutter/material.dart';
import 'discovery.dart';
class UserLogin extends StatelessWidget {
  final e=TextEditingController(text: 'ananya@demo.com'); final p=TextEditingController(text: 'demo123');
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text('User Login - Riva Dil')), body: Padding(padding: EdgeInsets.all(20), child: Column(children: [Icon(Icons.favorite, size: 60, color: Colors.pink), TextField(controller: e, decoration: InputDecoration(labelText: 'Email', border: OutlineInputBorder())), SizedBox(height: 10), TextField(controller: p, obscureText: true, decoration: InputDecoration(labelText: 'Password', border: OutlineInputBorder())), SizedBox(height: 20), SizedBox(width: double.infinity, child: ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: Colors.pink, padding: EdgeInsets.symmetric(vertical: 15)), onPressed: (){ Navigator.pushReplacement(context, MaterialPageRoute(builder: (_)=> DiscoveryScreen())); }, child: Text('Login & Find Matches', style: TextStyle(color: Colors.white))))])));
  }
}
