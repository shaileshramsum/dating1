
import 'package:flutter/material.dart';
import 'package:flutter_card_swiper/flutter_card_swiper.dart';
class DiscoveryScreen extends StatefulWidget {
  @override
  _DiscoveryScreenState createState() => _DiscoveryScreenState();
}
class _DiscoveryScreenState extends State<DiscoveryScreen> {
  final CardSwiperController controller=CardSwiperController();
  List<Map<String, dynamic>> users=[
    {'name':'Ananya','age':23,'city':'Kanpur','bio':'Coffee Lover','img':'https://i.pravatar.cc/400?img=5'},
    {'name':'Riya','age':22,'city':'Lucknow','bio':'Gym Girl','img':'https://i.pravatar.cc/400?img=9'},
    {'name':'Sneha','age':24,'city':'Delhi','bio':'MBA','img':'https://i.pravatar.cc/400?img=32'},
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text('Riva Dil - Discovery')), body: Column(children: [Expanded(child: CardSwiper(controller: controller, cardsCount: users.length, cardBuilder: (c,i,h,v){ final u=users[i]; return Container(decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), image: DecorationImage(image: NetworkImage(u['img']), fit: BoxFit.cover)), child: Container(decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), gradient: LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [Colors.black87, Colors.transparent])), padding: EdgeInsets.all(20), child: Column(mainAxisAlignment: MainAxisAlignment.end, crossAxisAlignment: CrossAxisAlignment.start, children: [Text(u['name']+', '+u['age'].toString(), style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)), Text(u['city']+' - '+u['bio'], style: TextStyle(color: Colors.white70))]))); })), Padding(padding: EdgeInsets.all(20), child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [FloatingActionButton(onPressed: ()=>controller.swipeLeft(), backgroundColor: Colors.white, child: Icon(Icons.close)), FloatingActionButton(onPressed: ()=>controller.swipeRight(), backgroundColor: Colors.pink, child: Icon(Icons.favorite, color: Colors.white))])), ElevatedButton(onPressed: (){ showDialog(context: context, builder: (_)=> AlertDialog(title: Text('Premium ₹299'), content: Text('Razorpay se pay karo'), actions: [TextButton(onPressed: ()=>Navigator.pop(context), child: Text('Pay Now'))])); }, child: Text('Get Premium'))]));
  }
}
