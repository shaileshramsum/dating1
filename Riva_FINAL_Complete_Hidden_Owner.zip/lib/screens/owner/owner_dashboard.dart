
import 'package:flutter/material.dart';
class OwnerDashboard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text('Owner Dashboard - Riva Dil'), backgroundColor: Colors.pink), body: ListView(padding: EdgeInsets.all(16), children: [Row(children: [Expanded(child: Card(child: ListTile(title: Text('Total Users'), trailing: Text('1,248', style: TextStyle(fontWeight: FontWeight.bold))))), Expanded(child: Card(child: ListTile(title: Text('Revenue'), trailing: Text('₹12,400', style: TextStyle(fontWeight: FontWeight.bold)))))]), SizedBox(height: 20), Text('All Users - Block/Delete', style: TextStyle(fontWeight: FontWeight.bold)), ListTile(title: Text('Ananya - Kanpur'), subtitle: Text('Premium Paid'), trailing: Icon(Icons.block, color: Colors.red)), ListTile(title: Text('Riya - Lucknow'), subtitle: Text('Free'), trailing: Icon(Icons.block, color: Colors.red)), SizedBox(height: 20), ElevatedButton(onPressed: (){}, child: Text('Export Data to Excel'))]));
  }
}
