
import 'package:flutter/material.dart';
import 'owner_dashboard.dart';
class OwnerLoginHidden extends StatelessWidget {
  final e=TextEditingController(text: 'owner@rivadil.com'); final p=TextEditingController(text: 'owner123');
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text('Owner Login - SECRET - Only You')), body: Padding(padding: EdgeInsets.all(20), child: Column(children: [Icon(Icons.admin_panel_settings, size: 80, color: Colors.pink), SizedBox(height: 20), Text('Ye screen sirf tum dekh sakte ho - 5 tap se aayi hai', style: TextStyle(color: Colors.red), textAlign: TextAlign.center), TextField(controller: e, decoration: InputDecoration(labelText: 'Owner Email', border: OutlineInputBorder())), SizedBox(height: 10), TextField(controller: p, obscureText: true, decoration: InputDecoration(labelText: 'Password', border: OutlineInputBorder())), SizedBox(height: 20), SizedBox(width: double.infinity, child: ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: Colors.pink, padding: EdgeInsets.symmetric(vertical: 15)), onPressed: (){ if(e.text=='owner@rivadil.com' && p.text=='owner123'){ Navigator.push(context, MaterialPageRoute(builder: (_)=> OwnerDashboard())); } }, child: Text('Login as Owner', style: TextStyle(color: Colors.white))))])));
  }
}
