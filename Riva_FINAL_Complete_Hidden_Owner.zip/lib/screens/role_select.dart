
import 'package:flutter/material.dart';
import 'user/user_login.dart';
import 'owner/owner_login.dart';
class RoleSelectHidden extends StatefulWidget {
  @override
  _RoleSelectHiddenState createState() => _RoleSelectHiddenState();
}
class _RoleSelectHiddenState extends State<RoleSelectHidden> {
  int tapCount=0; DateTime? lastTap;
  void _secretTap(){
    final now=DateTime.now();
    if(lastTap==null || now.difference(lastTap!).inSeconds>2) tapCount=1; else tapCount++;
    lastTap=now;
    if(tapCount>=5){ tapCount=0; ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Owner Mode Activated'))); Navigator.push(context, MaterialPageRoute(builder: (_)=> OwnerLoginHidden())); }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(body: Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [Color(0xFFFF4B6E), Color(0xFFFF8C42)])), child: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [GestureDetector(onTap: _secretTap, child: Icon(Icons.favorite, size: 80, color: Colors.white)), Text('Riva Dil', style: TextStyle(fontSize: 42, fontWeight: FontWeight.bold, color: Colors.white)), SizedBox(height: 50), ElevatedButton(style: ElevatedButton.styleFrom(padding: EdgeInsets.symmetric(horizontal: 60, vertical: 15), backgroundColor: Colors.white, foregroundColor: Colors.pink), onPressed: ()=> Navigator.push(context, MaterialPageRoute(builder: (_)=> UserLogin())), child: Text('Get Started ❤️', style: TextStyle(fontSize: 18)))]))));
  }
}
