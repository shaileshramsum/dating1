
import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';
void main() { WidgetsFlutterBinding.ensureInitialized(); runApp(RivaApp()); }
class RivaApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(title: 'Riva Dil', debugShowCheckedModeBanner: false, theme: ThemeData(primarySwatch: Colors.pink, useMaterial3: true), home: SplashScreen());
  }
}
